(** the type of the command, in which the user can choose their next action, 
    practice mode, and preference of a shuffled deck or not *)
type command =
  | Next
  | Flip
  | Quit
  | Random
  | Ordered 
  | Practice
  | Test 

exception Empty 

(** user input is malformed *)
exception Malformed

(**[remove_space lst] takes in a [lst] corresponding to strings from the parsed 
   command and evaluates to the list with all the space elements removed*) 
let rec remove_space lst = 
  match lst with
  | [] -> []
  | h::t -> if h <> "" then (h) :: remove_space t else remove_space t

(**[parse str] takes in a [string] and  removes spaces, then checks if the 
   inputs are valid. If so, it evaluates to a [command] if the inputs are
   valid- returns [Quit] the game if the input is quit, and [Next] flash card
   term if the command is [Next]. If the command is empty, it [parse] returns 
   [Empty], and if it is invalid, it returns [Malformed]*)
let parse str =
  if String.length str = 0 then raise (Empty) else 
    let trimmed_str = String.trim str in 
    let word_lst = String.split_on_char ' ' trimmed_str in 
    let word_lst_no_space = remove_space word_lst in 
    match word_lst_no_space with
    | [] -> raise Malformed
    | h::t -> if h = "next" then Next
      else if h = "flip" then Flip
      else if h = "quit" then Quit
      else if h = "p" then Practice
      else if h = "t" then Test
      else if h = "yes" then Random 
      else if h = "no" then Ordered 
      else raise Malformed
