open OUnit2
open Flashcard
open Command
open State


let deck_3110 = parse_csv "3110small.csv"
let first_card_3110_opt = Some {front="syntax";back="how code is written"}
let first_card_3110 = {front="syntax";back="how code is written"}

let parse_csv_tests = 
  [
    "CSV test 0" >:: (fun _ -> 
        assert_equal (first_card deck_3110) first_card_3110_opt);
    "CSV test 1" >:: (fun _ -> 
        assert_equal (List.length deck_3110) 5);
  ]

let flashcard_tests = 
  [
    "Flashcard test 0" >:: (fun _ -> 
        assert_equal (term first_card_3110 deck_3110) "syntax");
    "Flashcard test 1" >:: (fun _ -> 
        assert_equal (definition first_card_3110 deck_3110) 
          "how code is written");

  ] 

let str1 = "hi     "
let trim_split = String.split_on_char ' ' (String.trim str1)
let str2 = "   hi     there    "
let trim_split_2 = String.split_on_char ' ' (String.trim str2)

let command_tests = 
  [
    "Command test 0" >:: (fun _ -> 
        assert_equal (remove_space ["h";"i";""]) ["h";"i"]);
    "Command test 1" >:: (fun _ -> 
        assert_equal (remove_space trim_split) ["hi"]);
    "Command test 2" >:: (fun _ -> 
        assert_equal (remove_space trim_split_2) ["hi";"there"]);
    "Command test 3" >:: (fun _ -> 
        assert_equal (parse " flip   ") Flip);
    "Command test 4" >:: (fun _ -> 
        assert_equal (parse "     yes") Random);
    "Command test 5" >:: (fun _ -> 
        assert_equal (parse "p") Practice);
  ]

let state_3110 = {
  deck=deck_3110; 
  current= first_card_3110_opt;
  thumbs_up=[]; 
  thumbs_down=[]; 
  score = 0;
  correct=[]; 
  incorrect=[]; 
}

let state_3110_2 = {
  deck=deck_3110; 
  current= Some {front="immutable";back="state is not changed"};
  thumbs_up=[]; 
  thumbs_down=[]; 
  score = 0;
  correct=[]; 
  incorrect=[]; 
}

let state_tests = 
  [
    "State test 0" >:: (fun _ -> 
        assert_equal (init_state deck_3110) state_3110);
    "State test 1" >:: (fun _ -> 
        assert_equal (deck state_3110) deck_3110);
    "State test 2" >:: (fun _ -> 
        assert_equal (current_card state_3110) first_card_3110_opt);
    "State test 3" >:: (fun _ -> 
        assert_equal (next state_3110) state_3110_2);
    "State test 4" >:: (fun _ -> 
        assert_equal (List.length (shuffle_deck deck_3110)) 
          (List.length deck_3110));
    "State test 5" >:: (fun _ -> 
        assert_equal (List.length (deck (randomize state_3110)))
          (List.length (deck state_3110))); 
    "State test 3" >:: (fun _ -> 
        assert_equal (List.length (deck (next state_3110)))
          (List.length (deck state_3110_2)));
  ] 

let suite =
  "search test suite"  >::: List.flatten [
    parse_csv_tests;
    flashcard_tests;
    command_tests;
    state_tests;
  ]

let _ = run_test_tt_main suite