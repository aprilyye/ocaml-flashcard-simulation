open Flashcard

(** Represents the abstract type of values representing the study state,
    including an deck [deck], current card [current], thumbs up list
    [thumbs_up], thumbs_down list [thumbs_down], score [score], correct list 
    [correct], and incorrect list [incorrect]. *)
type t = {
  deck: Flashcard.t;
  current: notecard option;
  thumbs_up: Flashcard.t;
  thumbs_down: Flashcard.t;
  score: int;
  correct: Flashcard.t;
  incorrect: Flashcard.t;
}

(** [init_state deck] is the initial state of the game when studying the deck
    [deck]. In that state the user is currently looking at the first card of
    the deck, and all other list trackers are empty. *)
let init_state deck=
  {
    deck=deck; 
    current= first_card deck;
    thumbs_up=[]; 
    thumbs_down=[]; 
    score = 0;
    correct=[]; 
    incorrect=[]; 
  }

(* the state [st] of the current deck *)
let deck st = 
  st.deck

(* the state [st] of the current card *)
let current_card st =
  st.current

(**[find_next_card deck current] returns a [card] [option] representing 
   theh next card after [current] in [deck], and [None] if [current] is the 
   last card in [deck] *)
let rec find_next_card deck current = 
  match deck with 
  | [] -> None
  | h::n::t -> if h = current then Some n else find_next_card (n::t) current
  | h::t -> if h = current && List.length t = 1 then Some (List.hd t) else None

(**[next st] returns the [state] where the next card field has been updated
   to the next card in the deck *) 
let next st =
  let deck = deck st in 
  match current_card st with 
  | None -> {st with current = None}
  | Some curr -> 
    ( match deck with 
      | [] ->  {st with current = None}
      | h::n::t -> if h = curr then {st with current = Some n}
        else let m = find_next_card (n::t) curr in {st with current = m}
      | h::t -> if h = curr && List.length t = 1 then 
          {st with current = Some (List.hd t)} else {st with current = None} )

(**[shuffle_deck deck] returns a [deck] with its [notecards] in a random order*)
let shuffle_deck deck =
  match deck with
  | [] -> deck
  | d -> let split_deck = List.partition (fun x -> Random.self_init (); 
                                           Random.bool ()) deck in 
    (List.rev (fst split_deck)) @ (List.rev (snd split_deck))

(**[randomize st] returns a new state that is the same as [st] 
   except with a shuffled [deck]*)
let randomize st = 
  let random_deck =  shuffle_deck st.deck in 
  {st with deck = random_deck; current = Flashcard.first_card random_deck}