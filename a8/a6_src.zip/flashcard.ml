open Unix
open Str

type front = string
type back = string

(** Type [notecard] denotes one notecard in the deck with a [front] (term)s
    and [back] (definition)*)
type notecard = {
  front: front;
  back: back;
}
(**Type [deck] is a [list] of [notecards]*)
type t = notecard list

(**[first_card deck] returns the a [card] [option] representing the first card 
   and fails if the [deck] is empty*)
let first_card (deck:t) = 
  match deck with 
  | [] -> failwith "no cards in deck"
  | h::t -> Some (h)

(**[find_card deck card] returns [card] if [card] is in [deck], otherwise 
   fails*)
let find_card deck card = 
  if List.mem card deck then card else failwith "card not in deck"

(**[term card deck] returns the [front] of [card] if [card] is in the [deck]
   and fails if [deck] is empty or [card] is not in [deck]*)
let term card deck =
  match deck with 
  | [] -> failwith ("no deck")
  | deck -> let found_card = find_card deck card in
    found_card.front

(**[definition card deck] returns the [back] of [card] if [card] is in the 
   [deck] and fails if [deck] is empty or [card] is not in [deck]*)
let definition card deck =
  match deck with 
  | [] -> failwith ("no deck")
  | deck -> let found_card = find_card deck card in
    found_card.back

(**[parse_line file] returns a [deck] from CSV input [file] and an empty [deck] 
   if the file is empty*)
let rec parse_line file = 
  match input_line file with 
  | exception exn -> []
  | line -> let comma = String.index line ',' in 
    let front = String.sub line 0 comma in 
    let back = String.sub line (comma+1) ((String.length line) - 
                                          (String.length front)-1) in
    {front = front; back = back}::(parse_line file)

(**[parse_csv csv] checks that [csv] is a .csv file and opens the file if it 
   is in the working directory, then parses the lines uses [parse_line]*)
let parse_csv (csv : string) = 
  if Filename.check_suffix csv ".csv" then 
    let file = open_in (getcwd () ^ Filename.dir_sep ^ csv) in
    parse_line file
  else failwith "File is not a CSV."
