open State 
open Flashcard  
open Command


(**[unknown_user_input] outputs a message if the user inputs something 
   other than a [command]*)
let unknown_user_input () = 
  (ANSITerminal.(print_string [red]
                   "\nI don't know what you are trying to say.\n"))

(**[print_front state] prints the term of the current [notecard] 
   and a message if the player has reached the end of the [deck]*)
let print_front st = 
  let deck = State.deck st  in 
  let card = State.current_card st in
  match card with
  | None -> 
    (ANSITerminal.(print_string [red] "\nCongrats! You are done with this deck.\n");
     print_endline "\n"; Pervasives.exit 0)
  | Some c -> let term = Flashcard.term c deck in
    ANSITerminal.(print_string [white;on_black] ("\n" ^ term ^"\n"))

(**[print_back st] prints the [back] of the notecard in the current state [st], 
   and fails if [st] does not have a current card*)
let print_back st = 
  let deck = State.deck st in 
  match State.current_card st with 
  | None -> failwith "No back card"
  | Some card -> 
    let definition = Flashcard.definition card deck in
    ANSITerminal.(print_string [black;on_white] ("\n" ^ definition ^"\n"))

(**[user_input] reads user input and parses the commands using [Command.parse]; 
   if the input is not a [command], an exception calls [unknown_user_input]*)
let rec user_input () =
  ANSITerminal.(print_string [default] ("\n"));
  print_string  "> ";
  match read_line () with
  | exception exn -> unknown_user_input (); user_input ()
  | cmd -> ( match Command.parse cmd with 
      | exception exn -> unknown_user_input (); user_input ()
      | _ -> Command.parse cmd )

let rec next_turn_test st = 
  failwith "Unimplemented"

and start_test_mode st = 
  failwith "Unimplemented"

(**[next_turn_practice st] prints output corresponding to the users [command], 
   and prompts the user to enter either [practice] or [test] mode at the 
   beginning/end of the deck and calls [start_practice_mode] or 
   [start_test_mode]
   (to be implemented in next sprint)*)
let rec next_turn_practice st  = 
  let cmd = user_input () in
  match cmd with 
  | Quit -> (ANSITerminal.(print_string [red] 
                             "\nHope you feel more prepared after studying, you got this!\n");
             print_endline "\n"; Pervasives.exit 0)
  | Flip -> print_back (st); next_turn_practice (st)
  | Next -> (let next = State.next st in 
             match State.current_card next with 
             | None -> (ANSITerminal.(print_string [red] "\nCongrats! You are done with this deck.");
                        print_string "\nEnter p to practice again or t to test.\n";
                        let cmd = user_input () in 
                        match cmd with 
                        | Quit -> (ANSITerminal.(print_string [red] 
                                                   "\nHope you feel more prepared after studying, you got this!\n");
                                   print_endline "\n"; Pervasives.exit 0)
                        | Practice -> let st = State.init_state (State.deck st) 
                          in start_practice_mode st
                        | Test -> failwith "unimplemented"
                        | _ -> unknown_user_input (); next_turn_practice st)
             | Some n -> print_front next ; next_turn_practice next )
  | _ -> unknown_user_input (); next_turn_practice st

(**[start_practice_mode state] starts the game with a shuffled or ordered 
   [deck] depending on user input and prints the [front] of the 
   first [notecard] to start the game*)
and start_practice_mode st = 
  ANSITerminal.(print_string [red] "\nShuffle the deck?"); 
  print_string "\nEnter yes or no.\n";
  let cmd = user_input () in 
  match cmd with 
  | Random -> (
      (let rand_state = State.randomize st in 
       let deck = State.deck rand_state in 
       match  Flashcard.first_card deck with 
       | None -> failwith "No cards in deck"
       | Some card -> let term = card.front in
         ANSITerminal.(print_string [white;on_black]
                         ("\n" ^ term ^"\n"));
         next_turn_practice rand_state)
    )
  | Ordered -> 
    (let deck = st |> State.deck in 
     match  Flashcard.first_card deck with 
     | None -> failwith "No cards in deck"
     | Some card -> let term = card.front in
       ANSITerminal.(print_string [white;on_black]
                       ("\n" ^ term ^"\n"));
       next_turn_practice st)
  | _ -> (unknown_user_input (); start_practice_mode st)

(** [start_study f] starts the study in file [f]. *)
let rec start_study deck =
  let cmd = user_input () in 
  match cmd with 
  | Quit -> (ANSITerminal.(print_string [red] 
                             "\nHope you feel more prepared after studying, you got this!\n");
             print_endline "\n"; Pervasives.exit 0)
  | Practice -> let st = State.init_state deck in start_practice_mode st
  | Test -> failwith "unimplemented"
  | _ -> unknown_user_input (); start_study deck

(**[main ()] prompts for the game to play, then starts it. *)
let main () =
  ANSITerminal.(print_string [red]
                  "\n\nWelcome to your study sesh!\n");
  print_endline "Please enter the name of the csv you want to study.\n";
  print_string  "> ";
  match read_line () with
  | exception exn -> Pervasives.exit 0
  | file_name -> (let file = parse_csv file_name in 
                  match file with 
                  | exception exn -> Pervasives.exit 0
                  | deck -> (ANSITerminal.(print_string [red]
                                             "\nWhat mode would you like to study in?"));
                    print_string "\nEnter p for practice or t for test.\n";
                    start_study deck)

let _ = main ()